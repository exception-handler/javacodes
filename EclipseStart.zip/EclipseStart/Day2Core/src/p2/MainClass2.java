package p2;



public class MainClass2 {

	public static void main(String[] args) {
	
		Employee e= new Employee();
		
		e.setMyEmployeeData(101,"Mike",2000);
		e.doPrint();

	}//main end

}//class end
