package p1;

public class Quiz {

	public static void main(String[] args) {
		
		

	}

}
