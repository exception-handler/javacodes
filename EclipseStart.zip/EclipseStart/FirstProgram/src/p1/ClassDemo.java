package p1;

import java.util.Scanner;

public class ClassDemo {
	int arr[] = new int[5];
	int arrNew[]=new int[5];
	static int temp;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ClassDemo cd=new ClassDemo();
		cd.input();
		cd.checkArray();
		
		cd.displayArray();
		
	}//main end
	
	public void input()
	{
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<arr.length;i++)
		{
			System.out.println("enter values for arr["+i+"] :- ");
			arr[i]=sc.nextInt();
		}
		
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
	}
	
	public  void checkArray()
	{
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=i+1;j<arr.length;j++)
			{
				if(arr[i]==arr[j])
				temp++;
			}
			
		}
		
		System.out.println(" repeated  : " +temp);
		temp=1;
	}//checkArray ends
	
	
	
	public void displayArray()
	{
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
	}
	
}//class end
// find non-repeated and repeated ones
//remove repeated ones