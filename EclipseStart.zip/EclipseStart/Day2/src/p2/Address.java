package p2;

public class Address {

	private int streetNo;
	private String streetName;
}
