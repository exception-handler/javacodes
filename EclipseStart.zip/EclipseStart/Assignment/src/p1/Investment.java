package p1;

public class Investment {

}
