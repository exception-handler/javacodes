package p1;

public class Electronics {

private int current;

public Electronics(int current) {
	super();
	this.current = current;
}

public int getCurrent() {
	return current;
}

public void setCurrent(int current) {
	this.current = current;
}

}
