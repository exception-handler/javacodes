package ans4;

public class SavingsAccount extends Account {

	public void interest()
	{
		int balance=getBalance();
		balance= (int) (balance+(balance*0.9));
		setBalance(balance);
	}
}
