package ans4;

public class CurrentAccount extends Account{
	
	

}
