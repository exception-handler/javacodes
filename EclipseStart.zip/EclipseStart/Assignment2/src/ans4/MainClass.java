package ans4;

import java.util.Scanner;

import p1.MainClass;

public class MainClass {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	MainClass runner = new MainClass();
	Account ac=new Account();
	while (true) {
		System.out.println(" ====== MENU ======");
		System.out.println("1. add account");
		System.out.println("2. deposit amount");
		System.out.println("3. display balnce");
		System.out.println("4. withdrawal amount");
		System.out.println("5. compute interest");
		System.out.println("0. EXIT");

		System.out.println("\n\n Enter Choice : ");

		int ch = Integer.parseInt(sc.nextLine());
		switch (ch) {
		case 1:
			
			break;
		case 2:
			System.out.println("enter amount to be deposited:");
			int amount=Integer.parseInt(sc.nextLine());
			ac.deposit(amount);
			break;
			
		case 3:
			System.out.println("enter account number:");
			int acc=Integer.parseInt(sc.nextLine());
			System.out.println("the balance is :"+ac.getBalance());	
			break;
			
		case 4:
			break;
			
		case 5:
			break;
		case 0:
			System.exit(0);
		default:
			System.out.println("Wrong Choice");

		}//switch end
	}//while end


	}//main end

}//class end
