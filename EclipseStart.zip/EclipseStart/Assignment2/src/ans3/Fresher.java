package ans3;

public class Fresher {

}
