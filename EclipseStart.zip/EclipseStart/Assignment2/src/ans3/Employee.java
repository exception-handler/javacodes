package ans3;

public class Employee {
	

}
