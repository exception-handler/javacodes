package ans4;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamCollector {

	public static void main(String[] args) {
		List<Employee> list=new ArrayList<>();
		list.add(new Employee(101, "Rohit"));
		list.add(new Employee(102, "Mohit"));
		
		Stream<Employee> str=list.stream();
		List<Employee> lstr=str.filter(x->x.getId()%2==0).collect(Collectors.toList());
		System.out.println(lstr);

	}

}
