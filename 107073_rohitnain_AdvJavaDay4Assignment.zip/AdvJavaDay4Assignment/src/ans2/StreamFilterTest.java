package ans2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import ans1.Employee;

public class StreamFilterTest {

	public static void main(String[] args) {
		List<Employee> strList=new ArrayList<Employee>();
		strList.add(new Employee("Rohit1", "IT", 1000000));
		strList.add(new Employee("abhi1", "HR", 150000));
		strList.add(new Employee("vipin1", "HR", 200000));
		strList.add(new Employee("deepak1", "ACCOUNTS", 100000));
		
		
		Stream<Employee> str0=strList.stream();
		Map<String, Long> count=
		str0.collect(Collectors.groupingBy(Employee::getDept,Collectors.counting()));
		System.out.println(count);
		System.out.println("-----------------------");
		Stream<Employee> str5=strList.stream();
		Double salary=str5.collect(Collectors.summingDouble(Employee::getSalary));
		System.out.println(salary);
		System.out.println("-----------------------");
		Stream<Employee> str=strList.stream();
		str.filter(e->e.getSalary()>200000).forEach(System.out::println);
		System.out.println("-----------------------");
		Stream<Employee> str1=strList.stream();
		str1.filter(e->e.getSalary()<200000).forEach(System.out::println);
		System.out.println("-----------------------");
		Stream<Employee> str2=strList.stream();
		str2.filter(e->e.getName().startsWith("a")).forEach(System.out::println);
		System.out.println("-----------------------");
		Stream<Employee> str3=strList.stream();
		str3.filter(e->e.getName().length()>5).forEach(System.out::println);
		System.out.println("-----------------------");
		Stream<Employee> str4=strList.stream();
		str4.map(e->e.getName().toUpperCase()).forEach(System.out::println);
	}

}
