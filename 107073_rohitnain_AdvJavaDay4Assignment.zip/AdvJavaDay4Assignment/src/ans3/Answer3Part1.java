package ans3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;



public class Answer3Part1 {

	public static void main(String[] args) {
		List<String> list=Arrays.asList("Rohit","Nain","Abhishek","Kala","Vipin","Sahu");
	//	list.stream().filter(x -> x.length()>4).forEach(System.out::println);;
		System.out.println(list);
		System.out.println();
		Stream<String> str=list.stream();
		List<String> lstr=str.filter(x->x.length()>5).collect(Collectors.toList());
		System.out.println(lstr);
		
		
		List<String> list1=Arrays.asList("Rohit","Nain","Abhishek","Kala","Vipin","Sahu");
		Stream<String> str1=list1.stream();
		String name=str1.map(x->x.toUpperCase()).collect(Collectors.joining(","));
		System.out.println();
		System.out.println(name);
		
		List<Integer> integerlist=Arrays.asList(10,20,30,40,50,60);
		Stream<Integer> str2=integerlist.stream();
		List<Integer> newlist=str2.map(x->x*x).collect(Collectors.toList());
		System.out.println(newlist);
		
		//str2.map(x->x*x).collect(Collectors.toList()).forEach(System.out::println);
		
	}

}
