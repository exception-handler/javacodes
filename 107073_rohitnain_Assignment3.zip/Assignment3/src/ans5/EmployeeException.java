package ans5;

public class EmployeeException extends Exception {


	public EmployeeException(String s)
	{
		System.out.println(s);
	}

	
}
