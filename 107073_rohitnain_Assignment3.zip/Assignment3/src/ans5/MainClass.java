package ans5;

public class MainClass {

	public static void main(String[] args) {
		
		try{
		Employee e1=new Employee(101, 10);
		Employee e2=new Employee(102, 5);
		Employee e3=new Employee(104, 55);
		}
		catch(EmployeeException e)
		{
			
		}
	}
}
