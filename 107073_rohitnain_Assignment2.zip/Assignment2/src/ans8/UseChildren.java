package ans8;

import java.util.Scanner;

public class UseChildren {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);

		
		Male m=new Male("Rohit");
		
		Female fm=new Female("Ritika");
	}

}
