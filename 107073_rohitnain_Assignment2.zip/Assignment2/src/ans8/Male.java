package ans8;

import java.util.Scanner;

public class Male extends Child {

	public Male(String name) {
		super(name,"Male");
		// TODO Auto-generated constructor stub
		this.setAge();
		this.display();
	}

	
	@Override
	public void setAge() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter age:");
		int age=Integer.parseInt(sc.nextLine());
		setAge(age);
		
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("Name is:"+getName());
		System.out.println("Gender is:"+getGender());
		System.out.println("Age is:"+getAge());
	}

}
