package ans5;

public interface IRestaurant {

	public Dish getDish(int dishId); 
}
