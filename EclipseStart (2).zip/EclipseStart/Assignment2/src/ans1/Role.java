package ans1;

public interface Role {
	public String getRoleName();
	
	public String getResponsibility();

}
