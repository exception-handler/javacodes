package p1;

public interface Iprint {

public void print();
}
