package ans6;

public class ScoreException extends  Exception{

	
	public ScoreException(String s) {
	System.out.println(s);
	}
}
