package com.generics;
public interface GenericInterface<T,U> {
void getData(T t,U u);
}
