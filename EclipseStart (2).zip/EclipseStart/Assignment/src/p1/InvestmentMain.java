package p1;

import java.util.Scanner;

public class InvestmentMain {

	public static void main(String[] args) {
		float savings;
		int amount;
		int temp;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter the amount for year");
		amount=Integer.parseInt(sc.nextLine());
		savings=(float)(0.5*amount);
		
		
	}//main end

}//main class end
