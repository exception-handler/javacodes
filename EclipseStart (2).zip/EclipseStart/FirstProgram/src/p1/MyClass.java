package p1;

public class MyClass {
//public and class are keywords
	
	public static void main(String[] args) {
		
		
		System.out.println("Rohit Nain");
		
		
	}//end main

}//end class
