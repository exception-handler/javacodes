package p1;
/**
 * java doc
 */
import java.util.Scanner;

public class ArrayDemo {

	public static void main(String[] args) {
	
		int arr[] = new int[5];
		int arr1[] = {10,20,30,40,50};
		
		Scanner sc=new Scanner(System.in);
		
		//no minus sign array[-2]
		//length() work with string
		//length  works with array
		
		for(int i=0;i<arr.length;i++)
		{
			System.out.println("enter values for arr["+i+"] :- ");
			arr[i]=sc.nextInt();
		}
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
		
		//new allocate memory at run time
		ArrayDemo obj = new ArrayDemo();
		System.out.println(arr);
		obj.sizeOfAnArray(arr);
		
	}//end main

	//return an array
	public int[] sizeOfAnArray(int x[])
	{
		int len = x.length;
		
		//for each loop
		for (int i : x) {
			System.out.println(i);
		}
		
		return x;

	}
}//end class
