package com.collection;

public class Employee1 implements Comparable<Employee1> {
	
	 int id;
	 String name;
	 int age;
	@Override
	public int compareTo(Employee1 o) {
		// TODO Auto-generated method stub
		return 0;
	}
	 
	
	 
	 
}
