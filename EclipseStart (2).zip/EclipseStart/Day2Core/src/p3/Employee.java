package p3;

public class Employee {

}
